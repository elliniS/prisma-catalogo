﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PrismaCatalogo.Migrations
{
    /// <inheritdoc />
    public partial class AlterProdutoFilho_produto : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "FotoBytes",
                table: "ProdutosFilhos");

            migrationBuilder.DropColumn(
                name: "FotoBytes",
                table: "Produtos");

            migrationBuilder.AddColumn<bool>(
                name: "Ativo",
                table: "ProdutosFilhos",
                type: "boolean",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "Ativo",
                table: "Produtos",
                type: "boolean",
                nullable: false,
                defaultValue: false);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Ativo",
                table: "ProdutosFilhos");

            migrationBuilder.DropColumn(
                name: "Ativo",
                table: "Produtos");

            migrationBuilder.AddColumn<string[]>(
                name: "FotoBytes",
                table: "ProdutosFilhos",
                type: "text[]",
                nullable: true);

            migrationBuilder.AddColumn<string[]>(
                name: "FotoBytes",
                table: "Produtos",
                type: "text[]",
                nullable: true);
        }
    }
}
