﻿using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

namespace PrismaCatalogo.Migrations
{
    /// <inheritdoc />
    public partial class CreateProdutoFilho : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "ProdutosFilhos",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    Nome = table.Column<string>(type: "text", nullable: false),
                    Preco = table.Column<double>(type: "double precision", nullable: true),
                    QuantEstoque = table.Column<double>(type: "double precision", nullable: false),
                    FotoBytes = table.Column<string[]>(type: "text[]", nullable: true),
                    ProdutoId = table.Column<int>(type: "integer", nullable: false),
                    CorId = table.Column<int>(type: "integer", nullable: true),
                    TamanhoId = table.Column<int>(type: "integer", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProdutosFilhos", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ProdutosFilhos_Cores_CorId",
                        column: x => x.CorId,
                        principalTable: "Cores",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ProdutosFilhos_Produtos_ProdutoId",
                        column: x => x.ProdutoId,
                        principalTable: "Produtos",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ProdutosFilhos_Tamanhos_TamanhoId",
                        column: x => x.TamanhoId,
                        principalTable: "Tamanhos",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateIndex(
                name: "IX_ProdutosFilhos_CorId",
                table: "ProdutosFilhos",
                column: "CorId");

            migrationBuilder.CreateIndex(
                name: "IX_ProdutosFilhos_Nome",
                table: "ProdutosFilhos",
                column: "Nome",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_ProdutosFilhos_ProdutoId_CorId_TamanhoId",
                table: "ProdutosFilhos",
                columns: new[] { "ProdutoId", "CorId", "TamanhoId" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_ProdutosFilhos_TamanhoId",
                table: "ProdutosFilhos",
                column: "TamanhoId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ProdutosFilhos");
        }
    }
}
