﻿using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

namespace PrismaCatalogo.Migrations
{
    /// <inheritdoc />
    public partial class CreateProdutosfotos : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "produtoFilhoFotos",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    FotoBytes = table.Column<string>(type: "text", nullable: false),
                    ProdutoFilhoId = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_produtoFilhoFotos", x => x.Id);
                    table.ForeignKey(
                        name: "FK_produtoFilhoFotos_ProdutosFilhos_ProdutoFilhoId",
                        column: x => x.ProdutoFilhoId,
                        principalTable: "ProdutosFilhos",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "ProdutosFoto",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    FotoBytes = table.Column<string>(type: "text", nullable: false),
                    ProdutoId = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProdutosFoto", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ProdutosFoto_Produtos_ProdutoId",
                        column: x => x.ProdutoId,
                        principalTable: "Produtos",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_produtoFilhoFotos_ProdutoFilhoId",
                table: "produtoFilhoFotos",
                column: "ProdutoFilhoId");

            migrationBuilder.CreateIndex(
                name: "IX_ProdutosFoto_ProdutoId",
                table: "ProdutosFoto",
                column: "ProdutoId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "produtoFilhoFotos");

            migrationBuilder.DropTable(
                name: "ProdutosFoto");
        }
    }
}
