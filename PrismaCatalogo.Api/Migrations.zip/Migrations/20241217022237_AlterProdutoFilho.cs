﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PrismaCatalogo.Migrations
{
    /// <inheritdoc />
    public partial class AlterProdutoFilho : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_ProdutosFilhos_Nome",
                table: "ProdutosFilhos");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateIndex(
                name: "IX_ProdutosFilhos_Nome",
                table: "ProdutosFilhos",
                column: "Nome",
                unique: true);
        }
    }
}
